const express = require("express");
const cors = require("cors");

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));

// Set ALLOWED_ORIGINS in Render, e.g. https://your-site.netlify.app
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",").map(s => s.trim()).filter(Boolean);

app.use(cors({
  origin(origin, callback) {
    // Allow requests without Origin for simple health checks; browser origins must be allowlisted.
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error("Origin not allowed by CORS"));
  },
  methods: ["GET", "POST"],
  allowedHeaders: ["Content-Type"]
}));

app.get("/", (_req, res) => res.json({ service: "NHN AI backend", status: "ok" }));
app.get("/health", (_req, res) => res.json({ status: "ok" }));

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "message is required" });
    if (message.length > 4000) return res.status(413).json({ error: "message too long (max 4000 characters)" });

    const apiKey = process.env.AI_API_KEY;
    const apiUrl = process.env.AI_API_URL || "https://api.openai.com/v1/chat/completions";
    const model = process.env.AI_MODEL || "gpt-4o-mini";
    if (!apiKey) return res.status(503).json({ error: "AI backend is not configured" });

    const upstream = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: "তুমি NHN AI Assistant, একজন সহায়ক বাংলা AI। সাধারণত বাংলায় সংক্ষিপ্ত ও পরিষ্কার উত্তর দাও। ফোনের কোনো কাজ করেছ বলে দাবি করবে না যদি সত্যিই না করে থাকো।" },
          { role: "user", content: message }
        ],
        temperature: 0.7
      }),
      signal: AbortSignal.timeout(30000)
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("AI provider error status:", upstream.status);
      return res.status(502).json({ error: "AI provider request failed" });
    }

    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return res.status(502).json({ error: "AI provider returned an empty response" });
    }
    return res.json({ reply: reply.trim() });
  } catch (err) {
    console.error("Chat request failed:", err.message);
    return res.status(500).json({ error: "Unable to process chat request" });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`NHN AI backend listening on ${port}`));
