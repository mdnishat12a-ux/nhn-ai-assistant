# NHN AI Assistant — Backend + HTML starter

## What is included
- `index.html`: updated web interface with weather and Free Fire API buttons, plus a configurable chat backend URL.
- `server.js`: Node.js backend proxy. The AI API key stays on the server, not in HTML.
- `package.json`: Render install/start configuration.

## Deploy backend to Render
1. Create a GitHub repository and upload `server.js` and `package.json` to it.
2. In Render, create a **Web Service** from that repository.
3. Use Build Command: `npm install`
4. Use Start Command: `npm start`
5. Add environment variables in Render (do not put secrets in HTML):
   - `AI_API_KEY` = your AI provider API key
   - `AI_API_URL` = provider's OpenAI-compatible chat-completions endpoint (optional; default is OpenAI)
   - `AI_MODEL` = model name supported by your provider (optional; default `gpt-4o-mini`)
   - `ALLOWED_ORIGINS` = your exact published website origin, e.g. `https://your-site.netlify.app`
6. Deploy. Test `https://YOUR-BACKEND.onrender.com/health` and expect `{"status":"ok"}`.
7. Open `index.html`, find `https://YOUR-BACKEND-NAME.onrender.com/api/chat`, and replace it with your actual Render URL.
8. Upload the updated `index.html` to your existing Netlify site.

## Security notes
- Never put `AI_API_KEY` in `index.html` or share it in chat.
- Use an allowlisted `ALLOWED_ORIGINS` value; do not use `*` for production.
- Add authentication and rate limiting before sharing the service publicly. This starter has basic input length limits but is not a complete abuse-prevention system.
- The weather and player endpoints are third-party APIs and may fail due to provider availability or browser CORS restrictions.

## APK note
This bundle is not an APK. A real installable Android APK requires a native Android project and a build process. The backend can be reused by a native app, but the Android app must be built separately (e.g. with Android Studio or a compatible builder). Do not embed the AI secret key in the APK either.
